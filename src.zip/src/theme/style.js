import { StyleSheet } from 'react-native';
import Colors from './colors';
import { Matrics } from './matrics';

const C_Style = StyleSheet.create({

  // inputBoxView: {
  //   flexDirection: 'row',
  //   alignItems: 'center',
  //   backgroundColor: Colors.WHITE,
  //   height: Matrics.vs60,
  //   marginTop: Matrics.vs5,
  //   borderRadius: Matrics.ms20,
  //   paddingHorizontal: Matrics.hs20,
  //   paddingBottom: Matrics.vs5,
  //   shadowColor: Colors.PRIMARYSHADOW,
  //   shadowOffset: {
  //     width: 0,
  //     height: 5
  //   },
  //   shadowOpacity: 0.2,
  //   shadowRadius: 10,
  //   elevation: 10,
  //   marginBottom: Matrics.vs10,
  //   marginHorizontal: Matrics.vs3
  // },


});

export default C_Style;