/* eslint-disable no-undef */
const Images = {
    arrow: require('../assets/images/common/leftArrow.png'),
    close: require('../assets/images/common/Close.png'),
    google: require('../assets/images/common/Frame.png'),
    menu: require('../assets/images/common/menu.png'),
    heart: require('../assets/images/common/heart.png'),

    // user: require('../assets/images/home/user.png'),
    // book: require('../assets/images/home/book.png'),
    // applogo: require('../assets/images/common/splashLogo.png'),
    // userContact: require('../assets/images/home/userContact.png'),
    // unChecked: require('../assets/images/home/unChecked.png'),
    // checked: require('../assets/images/home/checked.png'),
    // defaultImage: require('../assets/images/common/defaultImage.png'),
    // plus: require('../assets/images/voi/plus.png'),
    // closeImage: require('../assets/images/common/closeImage.png'),
    // defaultphoto: require('../assets/images/common/defaultphoto.png'),
    // logoText: require('../assets/images/common/newLogoText.png'),
    // editLogo: require('../assets/images/home/edit.png')
}
export default Images;
