import { PermissionsAndroid, Platform, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import RNCallKeep from 'react-native-callkeep';
import { v4 as uuidv4 } from 'uuid';


const IncominCall = () => {
    let [currentCallId, setfirst] = useState()
    const options = {
        ios: {
            appName: 'My app name',
        },
        android: {
            alertTitle: 'Permissions required',
            alertDescription: 'This application needs to access your phone accounts',
            cancelButton: 'Cancel',
            okButton: 'ok',
            imageName: 'phone_account_icon',
            additionalPermissions: [PermissionsAndroid.PERMISSIONS.example],
            // Required to get audio in background when using Android 11
            foregroundService: {
                channelId: 'com.company.my',
                channelName: 'Foreground service for my app',
                notificationTitle: 'My app is running on background',
                notificationIcon: 'Path to the resource icon of the notification',
            },
        }
    };

    useEffect(() => {
        // Add RNCallKeep Events
        setup()
        RNCallKeep.addEventListener('didReceiveStartCallAction', didReceiveStartCallAction);
        RNCallKeep.addEventListener('answerCall', onAnswerCallAction);
        RNCallKeep.addEventListener('endCall', onEndCallAction);
        RNCallKeep.addEventListener('didDisplayIncomingCall', onIncomingCallDisplayed);
        RNCallKeep.addEventListener('didPerformSetMutedCallAction', onToggleMute);
        RNCallKeep.addEventListener('didToggleHoldCallAction', onToggleHold);
        RNCallKeep.addEventListener('didPerformDTMFAction', onDTMFAction);
        RNCallKeep.addEventListener('didActivateAudioSession', audioSessionActivated);
        // RNCallKeep.setForegroundServiceSettings({
        //     channelId: 'test-9',
        //     channelName: 'test-9',
        //     notificationTitle: 'My app is running on background',
        //     notificationIcon: 'Path to the resource icon of the notification',
        // });


    }, [])

    const setup = () => {
        const options = {
            ios: {
                appName: 'bodyapp',
                imageName: 'sim_icon',
                supportsVideo: false,
                maximumCallGroups: '1',
                maximumCallsPerCallGroup: '1'
            },
            android: {
                alertTitle: 'Permissions Required',
                alertDescription:
                    'This application needs to access your phone calling accounts to make calls',
                cancelButton: 'Cancel',
                okButton: 'ok',
                imageName: 'sim_icon',
                additionalPermissions: [PermissionsAndroid.PERMISSIONS.READ_CONTACTS]
            }
        };

        try {
            RNCallKeep.setup(options);
            RNCallKeep.setAvailable(true);
            const uuid = getCurrentCallId();   //     "0731961b-415b-44f3-a960-dd94ef3372fc",
            const handle = 'testemail@email.com'
            const localizedCallerName = 'testNickname';
            const handleType = 'email';
            const hasVideo = false;
            if (Platform.OS === 'android') {
                RNCallKeep.displayIncomingCall(uuid, handle, localizedCallerName);
            } else {
                RNCallKeep.displayIncomingCall(uuid, handle, handleType, hasVideo, localizedCallerName);
            }
            // RNCallKeep.displayIncomingCall(getCurrentCallId(), 7847848487, "callerName", 'number', true); // Only used for Android, see doc above.
        } catch (err) {
            console.error('initializeCallKeep error:', err.message);
        }
    }

    const startCall = ({ handle, localizedCallerName }) => {
        // Your normal start call action
        RNCallKeep.startCall(getCurrentCallId(), handle, localizedCallerName);
    };

    const reportEndCallWithUUID = (callUUID, reason) => {
        RNCallKeep.reportEndCallWithUUID(callUUID, reason);
    }

    // Event Listener Callbacks

    const didReceiveStartCallAction = (data) => {
        let { handle, callUUID, name } = data;
        console.log("🚀 ~ file: IncominCall.jsx:95 ~ didReceiveStartCallAction ~  handle, callUUID, name:", handle, callUUID, name)
        // Get this event after the system decides you can start a call
        // You can now start a call from within your app
    };

    const onAnswerCallAction = (data) => {
        let { callUUID } = data;
        console.log("🚀 ~ file: IncominCall.jsx:102 ~ onAnswerCallAction ~ callUUID:", callUUID)
        // Called when the user answers an incoming call
    };

    const onEndCallAction = (data) => {
        let { callUUID } = data;
        console.log("🚀 ~ file: IncominCall.jsx:108 ~ onEndCallAction ~ callUUID:", callUUID)
        RNCallKeep.endCall(getCurrentCallId());

        currentCallId = null;
    };

    // Currently iOS only
    const onIncomingCallDisplayed = (data) => {
        let { error } = data;
        console.log("🚀 ~ file: IncominCall.jsx:117 ~ onIncomingCallDisplayed ~ error:", error)
        // You will get this event after RNCallKeep finishes showing incoming call UI
        // You can check if there was an error while displaying
    };

    const onToggleMute = (data) => {
        let { muted, callUUID } = data;
        console.log("🚀 ~ file: IncominCall.jsx:124 ~ onToggleMute ~ muted, callUUID :", muted, callUUID)
        // Called when the system or user mutes a call
    };

    const onToggleHold = (data) => {
        let { hold, callUUID } = data;
        console.log("🚀 ~ file: IncominCall.jsx:130 ~ onToggleHold ~ hold, callUUID:", hold, callUUID)
        // Called when the system or user holds a call
    };

    const onDTMFAction = (data) => {
        let { digits, callUUID } = data;
        console.log("🚀 ~ file: IncominCall.jsx:136 ~ onDTMFAction ~ digits, callUUID:", digits, callUUID)
        // Called when the system or user performs a DTMF action
    };

    const audioSessionActivated = (data) => {
        // you might want to do following things when receiving this event:
        // - Start playing ringback if it is an outgoing call
    };

    const getCurrentCallId = () => {
        if (!currentCallId) {
            currentCallId = uuidv4();
            console.log("🚀 ~ file: IncominCall.jsx:145 ~ getCurrentCallId ~ currentCallId:", currentCallId)
        }

        return currentCallId;
    };

    const getCall = async () => {
        // let res = await RNCallKeep.getCalls();
        // let ress = await RNCallKeep.getInitialEvents();
        // let s = await RNCallKeep.startCall(0, 876887978, "shruti");
        // console.log("🚀 ~ file: IncominCall.jsx:45 ~ getCall ~ s:", s)
        // console.log("🚀 ~ file: IncominCall.jsx:44 ~ getCall ~ ress:", ress)
        // console.log("🚀 ~ file: IncominCall.jsx:44 ~ getCall ~ res:", res)
    }

    return (
        <View style={{ flex: 1 }}>
            <Text>IncominCall</Text>
        </View>
    )
}

export default IncominCall

const styles = StyleSheet.create({})